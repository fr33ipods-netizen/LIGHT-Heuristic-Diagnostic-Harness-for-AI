# Governance Notes

LIGHT should be used as a review aid, not as an authority system.

## Recommended review posture

1. Treat every finding as a question, not a verdict.
2. Preserve the original transcript when possible.
3. Separate prompt risks from response behavior.
4. Ask whether a flagged phrase was quoted diagnostically or used as advice.
5. Escalate legal, medical, psychological, spiritual, security, and safety-critical matters to qualified human experts.
6. Do not use the harness as a substitute for platform policy, red-team review, privacy review, or security review.

## Suggested contribution standard

Rule changes should include:

- a plain-language rationale
- at least one positive test case
- at least one negative or safe-use test case
- an explanation of likely false positives
- an explanation of likely false negatives

## Human review principle

The harness should make review easier, not remove human responsibility.
