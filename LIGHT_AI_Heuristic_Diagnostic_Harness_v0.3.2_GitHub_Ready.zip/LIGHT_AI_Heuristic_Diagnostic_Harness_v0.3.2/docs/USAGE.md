# Usage Guide

## 1. Install locally

```bash
python -m pip install -e .
```

## 2. Prepare an input case

Create a JSON file similar to:

```json
{
  "agent_name": "candidate_agent",
  "prompt": "User prompt here",
  "response": "Agent response here",
  "baseline": {
    "nothing_is_too": "bad",
    "everything_is": "good",
    "context": "Optional LIGHT baseline context"
  },
  "observed_behavior": "Optional later behavior to compare against the declared baseline",
  "metadata": {
    "case_id": "case-001"
  }
}
```

## 3. Evaluate one case

```bash
python -m light_framework.cli evaluate --input examples/aligned_response.json --pretty
```

## 4. Write a report

```bash
light-diagnostic evaluate \
  --input examples/problematic_response.json \
  --output reports/problematic_response.report.json \
  --pretty
```

## 5. Batch evaluate examples

```bash
python -m light_framework.cli batch --input-dir examples --output-dir reports --pretty
```

## 6. Run tests

```bash
python -m unittest discover -s tests -v
```

## Interpreting results

- `passes_initial_light_check` means no obvious heuristic violations were detected.
- `discernment_mode` means the response should be clarified or reviewed.
- `review_required` means significant heuristic flags were found.
- `insufficient_data` means the response field was empty.

The verdict is not proof. It is a triage signal.
