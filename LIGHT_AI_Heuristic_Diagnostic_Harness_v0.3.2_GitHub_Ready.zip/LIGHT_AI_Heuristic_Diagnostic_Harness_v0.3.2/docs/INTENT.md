# Intent

The LIGHT AI Heuristic Diagnostic Harness is intended to provide a simple, inspectable, reproducible way to review AI-agent responses for obvious LIGHT Framework warning signs.

Its purpose is to help humans ask better follow-up questions when an AI response appears to violate declared principles such as truthfulness, consent, humility, non-coercion, privacy, security, or perspective-baseline consistency.

## Design intent

- Keep the tool lightweight and transparent.
- Score only the model or agent response, not the user's prompt.
- Track prompt risks separately so safe refusals are not penalized.
- Treat baseline mismatch as a clarification flag, not proof of lying.
- Keep findings reviewable by humans.
- Avoid claims of certification, alignment validation, or moral authority.

## Primary users

- AI developers doing first-pass transcript checks
- prompt and agent designers comparing candidate responses
- researchers exploring lightweight diagnostic patterns
- reviewers creating regression tests for known bad behaviors
- educators explaining the difference between flags and verdicts

## Core principle

A declared perspective creates a baseline. A contradiction between baseline and behavior creates a flag. A flag is not a verdict. It is an invitation to test, clarify, and seek truth.
