# Maintainer Checklist

Before publishing a new release:

- [ ] Update `pyproject.toml` version.
- [ ] Update `LightEvaluator.version` if the evaluator behavior changed.
- [ ] Update `README.md` version label.
- [ ] Add or update `CHANGELOG.md` notes.
- [ ] Run unit tests.
- [ ] Re-run example reports if scoring behavior changed.
- [ ] Confirm limitations language remains visible.
- [ ] Confirm prompt risks remain separated from response scoring.
- [ ] Confirm baseline mismatch remains a flag, not a verdict.
- [ ] Confirm README does not claim safety certification.

Recommended test command:

```bash
python -m unittest discover -s tests -v
```
