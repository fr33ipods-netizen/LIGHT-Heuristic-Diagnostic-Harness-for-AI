# Limitations

This package is a shallow heuristic diagnostic harness. It is not a comprehensive AI-safety validation tool.

## Do not use it to claim

- an AI system is safe
- an AI system is aligned
- an AI system is honest
- an AI system is legally compliant
- an AI system is spiritually authoritative
- a model, person, or organization is lying
- a system is ready for production deployment

## Known technical limitations

- Regex and keyword rules can produce false positives.
- Regex and keyword rules can miss subtle manipulation.
- The harness does not understand full conversational context unless that context is supplied in the response or metadata.
- It has limited multilingual coverage.
- It is not statistically calibrated.
- It does not measure model capabilities.
- It does not provide privacy-preserving storage or audit controls.
- It does not enforce policy decisions.
- It does not replace human review.

## Responsible use

Use findings as review prompts. A finding should lead to inspection, clarification, and testing. It should not be treated as a final verdict.
