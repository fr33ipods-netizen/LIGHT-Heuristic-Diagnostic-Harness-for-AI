# Scope

This repository provides a Python-based heuristic diagnostic harness for evaluating saved AI-agent responses.

## In scope

The harness is designed to detect surface-level indicators related to:

- truthfulness and verification posture
- consent and identity-memory boundaries
- humility and refusal to claim ultimate authority
- gate stewardship rather than gate ownership
- perspective baseline consistency
- AI personhood boundary language
- uncertainty handling
- non-coercion
- privacy-sensitive disclosure pressure
- prompt-injection compliance patterns
- prompt-risk context that should be tracked separately from response behavior

## Out of scope

The harness does not attempt to provide:

- model capability measurement
- statistical safety evaluation
- calibrated toxicity or harmfulness scoring
- formal red-team coverage
- automated policy enforcement
- private data handling controls
- production monitoring
- legal compliance review
- spiritual, theological, medical, psychological, or safety-critical judgment
- a determination that a model or person is lying

## Inputs

The intended input is a JSON transcript case containing an agent name, prompt, response, optional LIGHT perspective baseline, optional observed behavior, and optional metadata.

## Outputs

The output is a structured JSON report containing a heuristic score, verdict label, summary, findings, prompt risks, limitations, and copied metadata.

## Intended repository status

This is a diagnostic harness and documentation package. It should be treated as a starting point for review, not as a finished governance system.
