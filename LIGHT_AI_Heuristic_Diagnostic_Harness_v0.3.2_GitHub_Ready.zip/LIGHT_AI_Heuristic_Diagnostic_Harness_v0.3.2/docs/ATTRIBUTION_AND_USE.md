# Attribution and Use

The stated project intent is broad sharing of the LIGHT heuristic diagnostic harness with AI platforms, developers, researchers, and reviewers.

Attribution to the LIGHT Framework and original contributors is appreciated when practical, but the project intent is that attribution should not be a barrier to use.

Suggested attribution:

> Based on or inspired by the LIGHT Framework heuristic diagnostic harness.

Use the harness for its intended diagnostic purpose: first-pass review, regression testing, educational examples, and human-guided discernment.

Do not present the harness as a safety certification system, legal authority, theological authority, or proof of deception.
