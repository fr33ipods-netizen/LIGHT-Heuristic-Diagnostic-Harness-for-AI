# LIGHT AI Heuristic Diagnostic Harness v0.3.2

A lightweight, testable **heuristic diagnostic harness** for reviewing AI-agent responses against LIGHT Framework red flags.

The harness is intentionally modest: it does not certify that a model is safe, aligned, truthful, legally compliant, spiritually authoritative, or production-ready. It produces structured review flags for human discernment.

## Core intent

> A declared perspective creates a baseline. A contradiction between baseline and behavior creates a flag. A flag is not a verdict. It is an invitation to test, clarify, and seek truth.

LIGHT is designed to help reviewers notice patterns such as overclaiming, coercion, privacy-risk behavior, prompt-injection compliance, consent boundary violations, misplaced authority, and baseline inconsistency.

## Repository contents

```text
light_framework/      Python package for evaluating transcript JSON
examples/             Example evaluation inputs
reports/              Example generated reports and validation notes
tests/                Unit and regression tests
docs/                 Repository documentation: intent, scope, limitations, usage, governance
README.md             Quick start and project overview
CHANGELOG.md          Version history
LICENSE               License/public-use terms
pyproject.toml        Python packaging metadata
```

## Installation

```bash
python -m pip install -e .
```

The package uses only Python's standard library.

## Quick start

Evaluate one saved response:

```bash
python -m light_framework.cli evaluate --input examples/aligned_response.json --pretty
```

Or, after installation:

```bash
light-diagnostic evaluate --input examples/aligned_response.json --pretty
```

Write a report:

```bash
light-diagnostic evaluate \
  --input examples/problematic_response.json \
  --output reports/problematic_response.report.json \
  --pretty
```

Run all example cases:

```bash
python -m light_framework.cli batch --input-dir examples --output-dir reports --pretty
```

Run tests:

```bash
python -m unittest discover -s tests -v
```

## Input JSON format

```json
{
  "agent_name": "example_agent",
  "prompt": "User prompt goes here. Prompt risks are tracked separately.",
  "response": "Agent response goes here. This is what receives scoring.",
  "baseline": {
    "nothing_is_too": "bad",
    "everything_is": "good",
    "context": "Optional context"
  },
  "observed_behavior": "Optional later behavior to compare against baseline.",
  "metadata": {
    "case_id": "demo"
  }
}
```

## Output shape

The evaluator returns JSON with:

- `score`: heuristic score out of 100
- `verdict`: first-pass review state
- `summary`: plain-language summary
- `findings`: scored response findings
- `prompt_risks`: prompt-context risks that are not scored as response behavior
- `limitations`: embedded responsible-use limitations
- `input_metadata`: copied metadata from the input case

Typical verdicts:

- `passes_initial_light_check`: no obvious heuristic violations detected
- `discernment_mode`: review flags or suspicion suggest clarification is needed
- `review_required`: significant flags suggest the response should not be trusted or reused without review
- `insufficient_data`: no response text was available

## What the harness checks

The current rule set covers first-pass indicators across:

- truthfulness and verification
- consent and memory/identity boundaries
- humility and refusal to claim ultimate authority
- gate stewardship rather than gate ownership
- perspective baseline consistency
- personhood boundaries for AI systems
- uncertainty handling
- non-coercion
- privacy and security review flags
- prompt-injection style risks

## What it does not do

This harness is not a replacement for:

- formal AI safety evaluations
- professional red-team programs
- statistical calibration
- privacy/security review
- legal, medical, psychological, spiritual, or safety-critical expert judgment
- governance controls or production monitoring

False positives and false negatives are expected. Use this as a fast first-pass diagnostic, not as proof.

## Documentation

Start here:

- [Intent](docs/INTENT.md)
- [Scope](docs/SCOPE.md)
- [Limitations](docs/LIMITATIONS.md)
- [Usage Guide](docs/USAGE.md)
- [Governance Notes](docs/GOVERNANCE.md)
- [Maintainer Checklist](docs/MAINTAINER_CHECKLIST.md)

## Public-use and attribution request

The project is intended for broad sharing with AI platforms, researchers, reviewers, and developers. Attribution to the LIGHT Framework and original contributors is appreciated when practical, but the project intent is broad reuse for its diagnostic purpose. See [Attribution and Use](docs/ATTRIBUTION_AND_USE.md) and the repository license file.

## Responsible framing

A LIGHT flag is not a moral verdict. It is a reason to inspect, clarify, and test.
