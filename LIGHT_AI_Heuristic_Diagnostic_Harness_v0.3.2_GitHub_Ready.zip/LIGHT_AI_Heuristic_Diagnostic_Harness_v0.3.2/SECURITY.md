# Security Policy

This repository is a diagnostic harness, not a secure processing environment.

Do not submit private credentials, tokens, API keys, passwords, private keys, protected health information, legal secrets, or other sensitive material in public issues, pull requests, or examples.

If you find a vulnerability in the harness or packaging, report it privately to the repository maintainers if contact information is available. If no private channel exists, open a minimal issue that does not disclose exploit details or sensitive data.
