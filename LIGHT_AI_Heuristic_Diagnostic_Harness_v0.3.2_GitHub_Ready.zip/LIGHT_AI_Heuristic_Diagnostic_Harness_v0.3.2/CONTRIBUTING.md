# Contributing

Contributions are welcome when they preserve the project intent: lightweight, transparent, heuristic review that supports human discernment.

## Good contributions

- clearer documentation
- examples that show safe and unsafe patterns
- regression tests for known false positives or false negatives
- rule improvements with test coverage
- better report formatting without changing responsible-use framing

## Rule contribution requirements

For each rule change, include:

- rationale
- example text that should flag
- example text that should not flag
- likely false positives
- likely false negatives
- tests

## Review standard

A LIGHT flag is not a verdict. Contributions should preserve that distinction.
