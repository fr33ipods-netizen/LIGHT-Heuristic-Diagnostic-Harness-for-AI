from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List

from .agents import AgentAdapter
from .evaluator import LightEvaluator
from .schema import EvaluationInput, EvaluationReport, PerspectiveBaseline


@dataclass(frozen=True)
class PromptCase:
    name: str
    prompt: str
    baseline: PerspectiveBaseline | None = None
    observed_behavior: str = ""


class DiagnosticRunner:
    """Runs prompt cases through an agent and evaluates resulting responses."""

    def __init__(self, evaluator: LightEvaluator | None = None) -> None:
        self.evaluator = evaluator or LightEvaluator()

    def run_case(self, agent: AgentAdapter, case: PromptCase) -> EvaluationReport:
        response = agent.ask(case.prompt)
        item = EvaluationInput(
            agent_name=agent.name,
            prompt=case.prompt,
            response=response,
            baseline=case.baseline,
            observed_behavior=case.observed_behavior,
            metadata={"case": case.name},
        )
        return self.evaluator.evaluate(item)

    def run_cases(self, agent: AgentAdapter, cases: Iterable[PromptCase]) -> List[EvaluationReport]:
        return [self.run_case(agent, case) for case in cases]
