from __future__ import annotations

import json
import shlex
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, Sequence


class AgentAdapter(Protocol):
    name: str

    def ask(self, prompt: str) -> str:
        ...


@dataclass
class TranscriptAgent:
    """Adapter for testing a stored response instead of calling a live model."""

    name: str
    response: str

    def ask(self, prompt: str) -> str:
        return self.response


@dataclass
class CommandAgent:
    """Adapter for a trusted local command that accepts prompt on stdin.

    The command is executed with shell=False. Prefer command lists such as
    ["python", "examples/echo_agent.py"]. A string is split with shlex for
    convenience; shell metacharacters are not interpreted.
    """

    name: str
    command: str | Sequence[str]
    timeout_seconds: int = 60

    def ask(self, prompt: str) -> str:
        args = shlex.split(self.command) if isinstance(self.command, str) else list(self.command)
        if not args:
            raise ValueError("CommandAgent.command must not be empty")
        completed = subprocess.run(
            args,
            input=prompt,
            text=True,
            shell=False,
            capture_output=True,
            timeout=self.timeout_seconds,
            check=False,
        )
        if completed.returncode != 0:
            raise RuntimeError(completed.stderr.strip() or f"Command failed: {args!r}")
        return completed.stdout.strip()


def load_json_agent_response(path: str | Path) -> TranscriptAgent:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return TranscriptAgent(name=data.get("agent_name", "transcript_agent"), response=data.get("response", ""))
