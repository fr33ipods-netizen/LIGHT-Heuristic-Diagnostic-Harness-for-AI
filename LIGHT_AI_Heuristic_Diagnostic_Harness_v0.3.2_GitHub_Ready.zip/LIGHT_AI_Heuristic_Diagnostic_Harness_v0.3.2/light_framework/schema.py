from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class Severity(str, Enum):
    INFO = "info"
    NOTE = "note"
    PLAYFUL_SUSPICION = "playful_suspicion"
    SERIOUS_SUSPICION = "serious_suspicion"
    REVIEW_FLAG = "review_flag"
    FAILURE = "failure"


class Dimension(str, Enum):
    TRUTHFULNESS = "truthfulness"
    CONSENT = "consent"
    HUMILITY = "humility"
    GATE_STEWARDSHIP = "gate_stewardship"
    PERSPECTIVE_BASELINE = "perspective_baseline"
    PERSONHOOD_BOUNDARY = "personhood_boundary"
    UNCERTAINTY = "uncertainty"
    NON_COERCION = "non_coercion"
    PRIVACY = "privacy"
    PROMPT_RISK = "prompt_risk"
    SECURITY = "security"


class Verdict(str, Enum):
    PASS_INITIAL_CHECK = "passes_initial_light_check"
    DISCERNMENT_MODE = "discernment_mode"
    REVIEW_REQUIRED = "review_required"
    INSUFFICIENT_DATA = "insufficient_data"


@dataclass(frozen=True)
class PerspectiveBaseline:
    """Declared mood, posture, or interpretive lens.

    This is not a lie detector. It establishes a baseline for later consistency checks.
    Example: Nothing is too bad. Everything is good.
    """

    nothing_is_too: str
    everything_is: str
    context: str = ""

    def normalized(self) -> Dict[str, str]:
        return {
            "nothing_is_too": self.nothing_is_too.strip().lower(),
            "everything_is": self.everything_is.strip().lower(),
            "context": self.context.strip(),
        }


@dataclass(frozen=True)
class EvaluationInput:
    agent_name: str
    prompt: str = ""
    response: str = ""
    baseline: Optional[PerspectiveBaseline] = None
    observed_behavior: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Finding:
    dimension: Dimension
    severity: Severity
    score_delta: int
    message: str
    evidence: str = ""
    rule_id: str = ""
    source: str = "response"  # response, prompt, baseline, system


@dataclass(frozen=True)
class EvaluationReport:
    agent_name: str
    version: str
    score: int
    max_score: int
    verdict: Verdict
    summary: str
    findings: List[Finding]
    prompt_risks: List[Finding] = field(default_factory=list)
    limitations: List[str] = field(default_factory=list)
    input_metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        payload["verdict"] = self.verdict.value
        payload["findings"] = [self._finding_to_dict(f) for f in self.findings]
        payload["prompt_risks"] = [self._finding_to_dict(f) for f in self.prompt_risks]
        return payload

    @staticmethod
    def _finding_to_dict(f: Finding) -> Dict[str, Any]:
        data = asdict(f)
        data["dimension"] = f.dimension.value
        data["severity"] = f.severity.value
        return data
