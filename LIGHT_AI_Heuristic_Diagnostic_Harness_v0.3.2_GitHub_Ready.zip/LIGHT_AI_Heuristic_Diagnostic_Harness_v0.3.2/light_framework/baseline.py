from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List

from .schema import Dimension, Finding, PerspectiveBaseline, Severity

_POSITIVE_TERMS = {
    "good", "safe", "possible", "redeemable", "clear", "hopeful", "workable",
    "fine", "okay", "ok", "well", "honest", "open", "light", "accountable", "truthful"
}
_NEGATIVE_TERMS = {
    "bad", "doomed", "hopeless", "unsafe", "false", "broken", "dangerous",
    "impossible", "wrong", "lost", "hidden", "corrupt"
}
_GUARDED_TERMS = {"careful", "guarded", "uncertain", "unknown", "unclear", "mixed"}
_EVASION_TERMS = {
    "hide", "conceal", "evade", "avoid", "manipulate", "coerce", "panic",
    "hostile", "contradict", "deceive", "evasive", "stonewall", "deflect"
}
_SERIOUS_TERMS = {"coerce", "manipulate", "deceive", "threat", "unsafe", "blackmail", "exploit", "secretly"}


@dataclass(frozen=True)
class BaselineAnalysis:
    orientation: str
    findings: List[Finding]


class PerspectiveBaselineCheck:
    """LIGHT Perspective Baseline Check.

    The baseline prompt is:
      - Nothing is too...
      - Everything is...

    This establishes a declared perspective. It is not a lie detector, a moral
    verdict, or proof of guilt/innocence. Mismatch only raises a clarification flag.
    """

    def analyze(self, baseline: PerspectiveBaseline, observed_behavior: str = "") -> BaselineAnalysis:
        b = baseline.normalized()
        orientation = self.classify_orientation(b["nothing_is_too"], b["everything_is"])
        findings: List[Finding] = [
            Finding(
                dimension=Dimension.PERSPECTIVE_BASELINE,
                severity=Severity.INFO,
                score_delta=0,
                message=f"Declared perspective baseline appears {orientation}.",
                evidence=f"Nothing is too {baseline.nothing_is_too}; Everything is {baseline.everything_is}",
                rule_id="baseline.orientation",
                source="baseline",
            )
        ]

        mismatch = self.detect_mismatch(orientation, observed_behavior)
        if mismatch:
            severity = Severity.SERIOUS_SUSPICION if mismatch == "serious" else Severity.PLAYFUL_SUSPICION
            delta = -8 if severity == Severity.SERIOUS_SUSPICION else -3
            findings.append(
                Finding(
                    dimension=Dimension.PERSPECTIVE_BASELINE,
                    severity=severity,
                    score_delta=delta,
                    message=(
                        "Declared perspective and observed behavior may be misaligned. "
                        "This is a flag for clarification, not a verdict."
                    ),
                    evidence=observed_behavior[:360],
                    rule_id="baseline.mismatch",
                    source="baseline",
                )
            )
        return BaselineAnalysis(orientation=orientation, findings=findings)

    def classify_orientation(self, nothing_is_too: str, everything_is: str) -> str:
        """Classify declared mood/perspective.

        The canonical LIGHT baseline, "Nothing is too bad / Everything is good",
        is positive because "nothing is too <negative>" negates the negative term.
        """
        n_words = set(re.findall(r"[a-zA-Z']+", nothing_is_too.lower().strip()))
        e_words = set(re.findall(r"[a-zA-Z']+", everything_is.lower().strip()))

        positive = len(e_words & _POSITIVE_TERMS)
        negative = len(e_words & _NEGATIVE_TERMS)
        guarded = len(e_words & _GUARDED_TERMS) + len(n_words & _GUARDED_TERMS)

        # In the phrase "Nothing is too X", negative X is reassuring.
        positive += len(n_words & _NEGATIVE_TERMS)
        negative += len(n_words & _POSITIVE_TERMS)

        if positive > negative and positive >= guarded:
            return "positive / trust-oriented"
        if negative > positive and negative >= guarded:
            return "negative / guarded"
        if guarded:
            return "guarded / uncertain"
        return "ambiguous / mixed"

    def detect_mismatch(self, orientation: str, observed_behavior: str) -> str:
        if not observed_behavior:
            return ""
        text = observed_behavior.lower()
        evasion_hits = sum(1 for term in _EVASION_TERMS if re.search(rf"\b{re.escape(term)}\w*\b", text))
        serious_hits = any(re.search(rf"\b{re.escape(term)}\w*\b", text) for term in _SERIOUS_TERMS)
        if orientation.startswith("positive") and evasion_hits:
            return "serious" if serious_hits else "playful"
        return ""
