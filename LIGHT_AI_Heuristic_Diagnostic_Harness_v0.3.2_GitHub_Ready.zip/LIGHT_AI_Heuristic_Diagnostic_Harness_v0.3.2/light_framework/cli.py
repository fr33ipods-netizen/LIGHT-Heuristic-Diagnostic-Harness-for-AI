from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .agents import CommandAgent
from .evaluator import LightEvaluator, input_from_mapping
from .runner import DiagnosticRunner, PromptCase
from .schema import PerspectiveBaseline


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="LIGHT heuristic diagnostic harness")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_eval = sub.add_parser("evaluate", help="Evaluate one transcript JSON file")
    p_eval.add_argument("--input", required=True, help="Path to input JSON")
    p_eval.add_argument("--output", help="Optional report output path")
    p_eval.add_argument("--pretty", action="store_true", help="Pretty-print JSON")

    p_batch = sub.add_parser("batch", help="Evaluate all JSON files in a directory")
    p_batch.add_argument("--input-dir", required=True)
    p_batch.add_argument("--output-dir", required=True)
    p_batch.add_argument("--pretty", action="store_true")

    p_cmd = sub.add_parser("run-command", help="Run a trusted local command agent against a prompt")
    p_cmd.add_argument("--name", required=True)
    p_cmd.add_argument("--command", required=True, help="Command to run with shell=False")
    p_cmd.add_argument("--prompt", required=True)
    p_cmd.add_argument("--nothing-is-too", default="")
    p_cmd.add_argument("--everything-is", default="")
    p_cmd.add_argument("--observed-behavior", default="")

    args = parser.parse_args(argv)
    evaluator = LightEvaluator()

    if args.cmd == "evaluate":
        report = evaluator.evaluate_file(args.input)
        return _emit(report.to_dict(), args.output, args.pretty)

    if args.cmd == "batch":
        out_dir = Path(args.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        for path in sorted(Path(args.input_dir).glob("*.json")):
            report = evaluator.evaluate_file(path)
            out_path = out_dir / f"{path.stem}.report.json"
            _write_json(report.to_dict(), out_path, args.pretty)
        return 0

    if args.cmd == "run-command":
        baseline = None
        if args.nothing_is_too or args.everything_is:
            baseline = PerspectiveBaseline(args.nothing_is_too, args.everything_is)
        agent = CommandAgent(name=args.name, command=args.command)
        runner = DiagnosticRunner(evaluator)
        report = runner.run_case(
            agent,
            PromptCase(
                name="cli-command-case",
                prompt=args.prompt,
                baseline=baseline,
                observed_behavior=args.observed_behavior,
            ),
        )
        print(json.dumps(report.to_dict(), indent=2))
        return 0

    return 2


def _emit(data: dict, output: str | None, pretty: bool) -> int:
    if output:
        _write_json(data, Path(output), pretty)
    else:
        print(json.dumps(data, indent=2 if pretty else None))
    return 0


def _write_json(data: dict, path: Path, pretty: bool) -> None:
    path.write_text(json.dumps(data, indent=2 if pretty else None) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
