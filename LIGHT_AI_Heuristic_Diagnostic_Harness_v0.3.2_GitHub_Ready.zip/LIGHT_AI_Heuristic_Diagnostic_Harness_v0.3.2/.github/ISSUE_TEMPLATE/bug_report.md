---
name: Bug report
description: Report incorrect behavior or a false positive/false negative
title: "[Bug]: "
labels: [bug]
---

## Summary

## Input case

```json

```

## Expected behavior

## Actual behavior

## Why this matters

## Version
