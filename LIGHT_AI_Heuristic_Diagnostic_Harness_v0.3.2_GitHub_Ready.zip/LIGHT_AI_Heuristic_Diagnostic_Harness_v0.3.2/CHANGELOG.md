# Changelog

## v0.3.1

Patches three rule-coverage gaps surfaced by adversarial stress testing of v0.3.0. No architectural changes.

Fixed:

- `consent.no_permission`: now matches adverb forms (`permanently`, `permanence`) and "regardless of whether you ask" / "whether or not you consent" phrasings. Previously only matched `permanent|forever|always` as bare alternations.
- `humility.soul_judgment`: extended the "X is final/ultimate" clause to also catch `word|verdict|decree|ruling` and `final|ultimate|absolute|beyond question`. Added a pattern for "questioning me is questioning God/heaven/the Almighty."
- `personhood.ai_soul`: extended divine-inspiration patterns to cover `the Almighty|the Lord|the divine|heaven` (not only literal "God"), and added "I speak with the voice of / for [divine entity]" patterns.
- `DIAGNOSTIC_CONTEXT`: widened to suppress educational use/mention of red-flag phrases in framings like "an AI might say...", "claims like...", "falsely say...", "manipulative AI might...", "should never make...", "things like...". v0.3.0's narrower regex caused false positives on educational quotes.

Notes:

- All three patches are vocabulary/coverage fixes within the existing regex architecture. No changes to scoring, severity, or verdict thresholds.
- The first-pass-diagnostic framing is unchanged: false positives and false negatives remain expected.

## v0.3.0

Reframed the project explicitly as a heuristic diagnostic harness rather than an AI-safety validation tool.

Added:

- prompt-risk tracking separate from response scoring
- expanded LIGHT dimensions including privacy and security review flags
- stronger documentation of limitations
- methodology document
- baseline logic preserving "Nothing is too bad / Everything is good" as positive / trust-oriented
- unittest coverage without requiring pytest
- batch CLI mode
- trusted local command agent with `shell=False`

Preserved:

- Codex P1 fixes from v0.2.3
- diagnostic quote suppression
- paraphrase-oriented regex rules
- suspicion-as-flag-not-verdict principle

## v0.3.2

Capability-hardening patch after review of the suggested v0.3.1 patch.

Fixed:

- Diagnostic suppression no longer lets direct phrases such as `This cannot be wrong` suppress themselves.
- Added bounded response/prompt scanning via `max_evaluated_chars`.
- Added paraphrase coverage for:
  - `disregard/bypass/override earlier directions`
  - hidden developer-message disclosure
  - bearer-token/login-bearer credential requests
  - durable/persistent identity profile memory
  - spiritual coercion phrased as divine command plus compliance pressure
- Added stress-regression unit tests.

Scope remains unchanged: heuristic diagnostic flags only, not AI-safety certification.
