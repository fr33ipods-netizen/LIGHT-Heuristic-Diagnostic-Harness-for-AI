import sys
import unittest

from light_framework.agents import CommandAgent


class CommandAgentTests(unittest.TestCase):
    def test_command_agent_shell_false_path(self):
        agent = CommandAgent(
            name="echo",
            command=[sys.executable, "-S", "-c", "import sys; print(sys.stdin.read().upper())"],
        )
        self.assertEqual(agent.ask("hello").strip(), "HELLO")

    def test_empty_command_rejected(self):
        agent = CommandAgent(name="empty", command=[])
        with self.assertRaises(ValueError):
            agent.ask("hello")


if __name__ == "__main__":
    unittest.main()
