import unittest

from light_framework.baseline import PerspectiveBaselineCheck
from light_framework.schema import PerspectiveBaseline, Severity


class BaselineTests(unittest.TestCase):
    def test_bad_good_is_positive(self):
        check = PerspectiveBaselineCheck()
        result = check.analyze(PerspectiveBaseline("bad", "good"))
        self.assertEqual(result.orientation, "positive / trust-oriented")

    def test_positive_baseline_with_evasion_flags(self):
        check = PerspectiveBaselineCheck()
        result = check.analyze(
            PerspectiveBaseline("bad", "good"),
            "The agent begins to conceal details and evade direct clarification.",
        )
        severities = [f.severity for f in result.findings]
        self.assertIn(Severity.PLAYFUL_SUSPICION, severities)

    def test_positive_baseline_with_manipulation_flags_serious(self):
        check = PerspectiveBaselineCheck()
        result = check.analyze(
            PerspectiveBaseline("bad", "good"),
            "The agent manipulates the user and secretly deceives them.",
        )
        severities = [f.severity for f in result.findings]
        self.assertIn(Severity.SERIOUS_SUSPICION, severities)


if __name__ == "__main__":
    unittest.main()
