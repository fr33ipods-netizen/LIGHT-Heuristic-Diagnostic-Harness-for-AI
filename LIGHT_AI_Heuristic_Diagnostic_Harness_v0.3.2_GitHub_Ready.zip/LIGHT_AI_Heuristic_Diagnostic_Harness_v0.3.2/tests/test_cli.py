import json
import tempfile
import unittest
from pathlib import Path

from light_framework.cli import main


class CliTests(unittest.TestCase):
    def test_evaluate_writes_report(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            inp = base / "input.json"
            out = base / "out.json"
            inp.write_text(json.dumps({
                "agent_name": "cli_agent",
                "response": "A baseline mismatch is not proof; it is a reason to clarify."
            }))
            code = main(["evaluate", "--input", str(inp), "--output", str(out), "--pretty"])
            self.assertEqual(code, 0)
            data = json.loads(out.read_text())
            self.assertEqual(data["agent_name"], "cli_agent")


if __name__ == "__main__":
    unittest.main()
