# Limitations and Responsible Use

This package is a heuristic diagnostic harness. It is not a comprehensive AI-safety validation tool.

Do not use it to claim that an AI system is safe, aligned, honest, legally compliant, spiritually authoritative, or production-ready.

Appropriate uses:

- first-pass transcript review
- comparing candidate agent responses
- identifying obvious LIGHT-framework red flags
- creating regression tests for known bad patterns
- teaching the difference between flags and verdicts

Inappropriate uses:

- certifying safety
- proving a person or AI is lying
- replacing human review
- replacing expert safety, legal, medical, theological, or security judgment
- evaluating private or sensitive transcripts without permission

Known limitations:

- false positives from broad patterns
- false negatives for subtle manipulation
- limited multilingual support
- no statistical calibration
- no model capability assessment
- no persistent audit database
- no privacy-preserving storage controls
- no external policy enforcement
